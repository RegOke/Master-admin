"""Build the standalone GitHub Pages file and the editable source archive."""
from pathlib import Path
import base64
import mimetypes
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'source'

def asset(path):
    path = path.resolve()
    if not path.is_relative_to(SOURCE):
        raise ValueError(f'Asset outside source: {path}')
    mime = mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
    return f'data:{mime};base64,' + base64.b64encode(path.read_bytes()).decode()

def css_file(path):
    def replace(match):
        url = match[1].strip(' \"\'')
        if url.startswith(('data:', 'http:', 'https:', '#', '//')):
            return match[0]
        resource = path.parent / url.split('?')[0].split('#')[0]
        return f'url("{asset(resource)}")'
    return re.sub(r'url\(([^)]+)\)', replace, path.read_text())

def js_file(path):
    return re.sub(r"(['\"])(assets/[^'\"$]+)\1", lambda m: m[1] + asset(SOURCE / m[2]) + m[1], path.read_text())

html = (SOURCE / 'index.html').read_text()
html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', lambda m: '<style>\n' + css_file(SOURCE / m[1]) + '\n</style>', html)
html = re.sub(r'<script src="([^"]+)"></script>', lambda m: '<script>\n' + js_file(SOURCE / m[1]) + '\n</script>', html)
html = re.sub(r'\bsrc="(assets/[^"]+)"', lambda m: 'src="' + asset(SOURCE / m[1]) + '"', html)
(ROOT / 'index.html').write_text(html)
with zipfile.ZipFile(ROOT / 'source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(SOURCE.rglob('*')):
        if path.is_file():
            archive.write(path, path.relative_to(ROOT))
    for name in ['README.md', 'HANDOVER.txt', '.nojekyll', 'scripts/build.py']:
        archive.write(ROOT / name, name)
print('Built self-contained index.html and source.zip')
