/* Standalone interaction layer. No requests or changes are sent to Advoc8. */
(() => {
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let dropdown, modal, lastFocus, toastTimer;
  const toast = text => {
    $('.prototype-toast')?.remove(); clearTimeout(toastTimer);
    const t=document.createElement('div');t.className='prototype-toast';t.role='status';t.textContent=text;document.body.append(t);
    toastTimer=setTimeout(()=>t.remove(),3500);
  };
  function closeDropdown(){dropdown?.remove();dropdown=null;$$('.select2-selection[aria-expanded="true"]').forEach(e=>e.setAttribute('aria-expanded','false'));}
  function renderSelection(select){
    const container=select.nextElementSibling;
    if(!container?.classList.contains('select2')) return;
    const rendered=$('.select2-selection__rendered',container);
    if(select.multiple){
      rendered.innerHTML=[...select.selectedOptions].map(o=>`<li class="select2-selection__choice" title="${esc(o.text)}"><span class="select2-selection__choice__remove" role="button" aria-label="Remove ${esc(o.text)}" data-option-value="${esc(o.value)}">×</span><span>${esc(o.text)}</span></li>`).join('')+'<li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" aria-label="Search '+esc(select.previousElementSibling?.textContent||'options')+'" style="width:.75em"></li>';
    }else{
      const text=select.selectedOptions[0]?.text||'';
      rendered.innerHTML=select.value?`<span class="select2-selection__clear" role="button" aria-label="Clear selection">×</span>${esc(text)}`:`<span class="select2-selection__placeholder">${esc(select.dataset.placeholder||'Choose an option')}</span>`;
      rendered.title=text;
    }
  }
  function showOptions(select,control){
    closeDropdown();control.setAttribute('aria-expanded','true');
    dropdown=document.createElement('div');dropdown.className='prototype-options';dropdown.setAttribute('role','listbox');
    const rect=control.getBoundingClientRect();Object.assign(dropdown.style,{top:`${rect.bottom+scrollY}px`,left:`${rect.left+scrollX}px`,width:`${rect.width}px`});
    const search=document.createElement('input');search.className='form-control form-control-sm';search.placeholder='Search';search.setAttribute('aria-label','Search options');
    const list=document.createElement('div');dropdown.append(search,list);document.body.append(dropdown);
    function draw(){
      list.replaceChildren();
      const options=[...select.options].filter(o=>o.value&&o.text.toLowerCase().includes(search.value.toLowerCase()));
      for(const o of options){const b=document.createElement('button');b.type='button';b.role='option';b.setAttribute('aria-selected',String(o.selected));b.textContent=o.text;b.onclick=()=>{if(select.multiple)o.selected=!o.selected;else select.value=o.value;renderSelection(select);select.dispatchEvent(new Event('change',{bubbles:true}));closeDropdown();control.focus();};list.append(b);}
      if(!options.length){const empty=document.createElement('div');empty.role='status';empty.textContent='No results found';list.append(empty);}
    }
    draw();search.addEventListener('input',draw);search.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();$('button',list)?.focus();}});search.focus();
    dropdown.addEventListener('keydown',e=>{const rows=$$('button',dropdown);const i=rows.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();rows[(i+(e.key==='ArrowDown'?1:-1)+rows.length)%rows.length]?.focus();}});
  }
  function closeModal(){modal?.remove();modal=null;document.body.classList.remove('prototype-modal-open');lastFocus?.focus();}
  function openModal(markup){
    closeDropdown();lastFocus=document.activeElement;modal=document.createElement('div');modal.className='prototype-modal-root';modal.innerHTML='<div class="prototype-backdrop"></div>'+markup;document.body.append(modal);document.body.classList.add('prototype-modal-open');
    $('.modal',modal)?.setAttribute('aria-labelledby','prototype-modal-title');const title=$('.modal-title',modal);if(title)title.id='prototype-modal-title';
    $('.close',modal)?.addEventListener('click',closeModal);$('input:not([type="hidden"]),select,textarea,button',modal)?.focus();
    $('form',modal)?.addEventListener('submit',e=>e.preventDefault());return modal;
  }
  function smallModal(title,body,action,onSave,danger=false){
    const root=openModal(`<div class="modal show" style="display:block;z-index:1010" role="dialog" aria-modal="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h4 class="modal-title">${esc(title)}</h4><button class="close" type="button" aria-label="Close">×</button></div><form><div class="modal-body">${body}</div><div class="modal-footer"><button type="button" class="btn btn-white" data-cancel>Cancel</button><button type="submit" class="btn btn-${danger?'danger':'primary'}">${esc(action)}</button></div></form></div></div></div>`);
    $('[data-cancel]',root).onclick=closeModal;$('form',root).addEventListener('submit',e=>{e.preventDefault();e.stopPropagation();onSave?.(root);closeModal();});
  }
  const field=(label,value='',type='text')=>`<div class="form-group"><label>${esc(label)}<input class="form-control" name="${esc(label)}" type="${type}" value="${esc(value)}"></label></div>`;
  function addressForm(card){
    const root=openModal($('#address-prototype-template').innerHTML);
    const form=$('form',root);const controls=$$('input[id^="master_address_"],select[id^="master_address_"]',form);
    if(card){
      $('.modal-title',root).textContent='Edit Address';$('[type="submit"]',form).value='Update Master address';
      const name=$('address .font-weight-bold',card)?.textContent.trim()||'';
      $('#master_address_name',form)?.setAttribute('value',name);
      const address=$('address',card);const lines=address?.innerText.split('\n').map(s=>s.trim()).filter(Boolean)||[];
      const phone=lines.find(s=>s.startsWith('P: '));if(phone)$('#master_address_phone',form).value=phone.slice(3);
      const remaining=lines.slice(1).filter(s=>!s.startsWith('P: '));
      const country=remaining.at(-1);if(country==='Australia'){remaining.pop();$('#master_address_country',form).value=country;}
      const city=remaining.at(-1)?.match(/^(.*?)\s+([A-Z]{2,3})\s+(\d{4})$/);if(city){remaining.pop();['city','state','postcode'].forEach((k,i)=>$('#master_address_'+k,form).value=city[i+1]);}
      ['line_1','line_2','line_3'].forEach((key,i)=>$('#master_address_'+key,form).value=remaining[i]||'');
      const type=$('.badge',card)?.textContent.trim();const select=$('select',form);const option=[...select.options].find(o=>o.text===type);if(option)select.value=option.value;
    }
    $$('select',root).forEach(s=>{s.classList.remove('select2-hidden-accessible');s.removeAttribute('aria-hidden');s.removeAttribute('tabindex');if(s.nextElementSibling?.classList.contains('select2'))s.nextElementSibling.remove();});
    form.addEventListener('submit',e=>{
      e.preventDefault();e.stopPropagation();const val=key=>$('#master_address_'+key,form)?.value.trim()||'';
      const name=val('name')||val('address_name')||'Address';const type=$('select',form)?.selectedOptions[0]?.text||'Office';
      const lines=[val('line_1'),val('line_2'),val('line_3'),[val('city'),val('state'),val('postcode')].filter(Boolean).join(' '),val('country')].filter(Boolean);
      if(!lines.length){$('input[id*="line_1"]',form)?.focus();return;}
      const node=card||$('#addresses > [id^="master_address_"]').cloneNode(true);if(!card){node.id='master_address_demo_'+Date.now();$('#addresses').insertBefore(node,$('#addresses > .col-12:last-child'));}
      $('address',node).innerHTML=`<div class="font-weight-bold">${esc(name)}</div>${lines.map(esc).join('<br>')}${val('phone')?'<br>P: '+esc(val('phone')):''}`;
      $('.badge',node).textContent=type;closeModal();toast(card?'Address updated in this prototype':'Address added in this prototype');
    });
  }
  document.addEventListener('submit',e=>{
    e.preventDefault();if(modal?.contains(e.target))return;
    toast('Master person updated in this prototype');
  });
  document.addEventListener('click',e=>{
    const clear=e.target.closest('.select2-selection__clear,.select2-selection__choice__remove');
    if(clear){e.preventDefault();e.stopPropagation();const s=clear.closest('.select2').previousElementSibling;if(s.multiple){const o=[...s.options].find(o=>o.value===clear.dataset.optionValue||o.text===clear.parentElement.title);if(o)o.selected=false;}else s.value='';renderSelection(s);return;}
    const selection=e.target.closest('.select2-selection');if(selection){const s=selection.closest('.select2').previousElementSibling;if(s?.tagName==='SELECT')showOptions(s,selection);return;}
    const toggle=e.target.closest('[data-toggle="dropdown"]');if(toggle){e.preventDefault();const menu=toggle.nextElementSibling;const open=menu?.classList.contains('show');$$('.dropdown-menu.show').forEach(x=>x.classList.remove('show'));menu?.classList.toggle('show',!open);toggle.setAttribute('aria-expanded',String(!open));return;}
    const collapse=e.target.closest('[data-toggle="collapse"]');if(collapse){e.preventDefault();const target=collapse.dataset.target||collapse.dataset.prototypePath;$(target)?.classList.toggle('show');return;}
    const trash=e.target.closest('fieldset button');if(trash?.querySelector('.fa-trash')){trash.closest('fieldset').remove();return;}
    if(e.target.closest('#addNameDropdown + .dropdown-menu button')){
      const row=document.createElement('fieldset');row.className='form-group';row.innerHTML='<input class="form-control form-control-sm mb-1" aria-label="Name label" placeholder="Label e.g. Nickname" style="width:150px"><div class="row"><div class="col"><input class="form-control" aria-label="Additional name" placeholder="Enter name"></div><div class="col-auto"><button type="button" class="btn btn-link text-danger" aria-label="Remove name"><i class="far fa-trash"></i></button></div></div>';$('#addNameDropdown').closest('.form-group').before(row);$$('.dropdown-menu.show').forEach(x=>x.classList.remove('show'));$('input',row).focus();return;
    }
    const link=e.target.closest('a[data-prototype-path]');
    if(link){
      e.preventDefault();const path=link.dataset.prototypePath;
      if(path.startsWith('#')&&path!=='#')return;
      if(path.includes('template_id=')&&modal){const lines=$('small',link)?.innerText.split('\n')||[];const form=$('form',modal);$('#master_address_name',form).value=$('strong',link).textContent;['line_1','line_2','line_3'].forEach((k,i)=>{if($('#master_address_'+k,form))$('#master_address_'+k,form).value=lines[i]||'';});$$('.dropdown-menu.show',modal).forEach(x=>x.classList.remove('show'));return;}
      if(path.includes('/master_addresses/new')){addressForm();return;}
      if(path.includes('/master_addresses/')){const card=link.closest('[id^="master_address_"]');if(path.endsWith('/edit'))addressForm(card);else smallModal('Delete address?','<p>This will remove this address from the prototype.</p>','Delete',()=>card?.remove(),true);return;}
      if(path.endsWith('/archive/edit')){smallModal('Delist & Archive Anthony Albanese','<p>Archive this master person?</p>','Delist & Archive',()=>toast('Archived in this prototype only'),true);return;}
      if(link.textContent.trim()==='Edit'&&path==='#'){['first_name','last_name'].forEach(k=>$('#master_person_'+k).readOnly=false);$('#master_person_first_name').focus();return;}
      if(link.textContent.trim()==='Clear'&&path==='#'){['first_name','last_name'].forEach(k=>$('#master_person_'+k).value='');return;}
      if(path.includes('/master_positions')&&!path.includes('/new')&&!path.includes('/edit')){$('h3.card-header-title', $('#staff'))?.scrollIntoView({behavior:'smooth'});$('#staff')?.scrollIntoView({behavior:'smooth'});return;}
      if(path.endsWith('/edit')||path.endsWith('/new')){const title=link.textContent.trim()||link.closest('.card')?.querySelector('h3')?.textContent.trim()||'Edit details';smallModal(title,field('Name',link.closest('.row')?.querySelector('h4')?.textContent.trim()||''),'Save changes',()=>toast('Changes saved in this prototype'));return;}
      toast('This prototype covers the master person edit page');return;
    }
    if(!e.target.closest('.prototype-options'))closeDropdown();
    if(!e.target.closest('.dropdown'))$$('.dropdown-menu.show').forEach(x=>x.classList.remove('show'));
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'){if(dropdown)closeDropdown();else closeModal();$$('.dropdown-menu.show').forEach(x=>x.classList.remove('show'));}
    if(modal&&e.key==='Tab'){const focusable=$$('button,input,select,textarea,a[href]',modal).filter(x=>x.getClientRects().length&&!x.disabled);const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
    if((e.key==='Enter'||e.key===' ')&&e.target.matches('.select2-selection')){e.preventDefault();e.target.click();}
  });
  window.addEventListener('resize',closeDropdown);
  // Captured enhancement widths must respond to the prototype's own viewport.
  $$('.select2-selection').forEach(e=>{const s=e.closest('.select2').previousElementSibling;const label=s?.id?document.querySelector(`label[for="${s.id}"]`):null;if(label){e.removeAttribute('aria-labelledby');e.setAttribute('aria-label',label.textContent.trim());}});
})();
