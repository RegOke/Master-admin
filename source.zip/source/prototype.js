/* Standalone interaction layer. No requests or changes are sent to Advoc8. */
(() => {
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let dropdown, dropdownControl, modal, lastFocus, toastTimer;
  const addressCardTemplate = $('#addresses > [id^="master_address_"]').cloneNode(true);
  const addressRecords = new WeakMap();
  let addressSequence = 0;
  function closeMenus(){
    $$('.dropdown-menu.show').forEach(menu=>menu.classList.remove('show'));
    $$('[data-toggle="dropdown"][aria-expanded="true"]').forEach(toggle=>toggle.setAttribute('aria-expanded','false'));
  }
  const toast = text => {
    $('.prototype-toast')?.remove(); clearTimeout(toastTimer);
    const t=document.createElement('div');t.className='prototype-toast';t.role='status';t.textContent=text;document.body.append(t);
    toastTimer=setTimeout(()=>t.remove(),3500);
  };
  function closeDropdown(restoreFocus=false){dropdown?.remove();dropdown=null;if(restoreFocus)dropdownControl?.focus();$$('.select2-selection[aria-expanded="true"]').forEach(e=>e.setAttribute('aria-expanded','false'));}
  function renderSelection(select){
    const container=select.nextElementSibling;
    if(!container?.classList.contains('select2')) return;
    const rendered=$('.select2-selection__rendered',container);
    if(select.multiple){
      rendered.innerHTML=[...select.selectedOptions].map(o=>`<li class="select2-selection__choice" title="${esc(o.text)}"><span class="select2-selection__choice__remove" role="button" aria-label="Remove ${esc(o.text)}" data-option-value="${esc(o.value)}">×</span><span>${esc(o.text)}</span></li>`).join('')+'<li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" aria-label="Search '+esc(select.previousElementSibling?.textContent||'options')+'" style="width:.75em"></li>';
    }else{
      const text=select.selectedOptions[0]?.text||'';
      rendered.innerHTML=select.value?`<span class="select2-selection__clear" role="button" aria-label="Clear selection">×</span>${esc(text)}`:`<span class="select2-selection__placeholder">${esc(select.dataset.placeholder||'Choose an option')}</span>`;
      rendered.title=text;
    }
  }
  function showOptions(select,control){
    closeDropdown();dropdownControl=control;control.setAttribute('aria-expanded','true');
    dropdown=document.createElement('div');dropdown.className='prototype-options';dropdown.setAttribute('role','listbox');if(select.dataset.contactName)dropdown.classList.add('contact-name-options');
    const rect=control.getBoundingClientRect();Object.assign(dropdown.style,{top:`${rect.bottom+scrollY}px`,left:`${rect.left+scrollX}px`,width:`${rect.width}px`});
    const search=document.createElement('input');search.className='form-control form-control-sm';search.placeholder='Search';search.setAttribute('aria-label','Search options');
    const list=document.createElement('div');if(!select.dataset.contactName)dropdown.append(search);dropdown.append(list);document.body.append(dropdown);
    function draw(){
      list.replaceChildren();
      const options=[...select.options].filter(o=>!o.disabled&&o.value&&o.text.toLowerCase().includes(search.value.toLowerCase()));
      for(const o of options){const b=document.createElement('button');b.type='button';b.role='option';b.setAttribute('aria-selected',String(o.selected));b.textContent=o.text;b.onclick=()=>{if(select.multiple)o.selected=!o.selected;else select.value=o.value;renderSelection(select);select.dispatchEvent(new Event('change',{bubbles:true}));closeDropdown();control.focus();};list.append(b);}
      if(!options.length){const empty=document.createElement('div');empty.role='status';empty.textContent='No results found';list.append(empty);}
    }
    draw();search.addEventListener('input',draw);search.addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();$('button',list)?.focus();}});if(select.dataset.contactName)$('button',list)?.focus();else search.focus();
    dropdown.addEventListener('keydown',e=>{const rows=$$('button',dropdown);const i=rows.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();rows[(i+(e.key==='ArrowDown'?1:-1)+rows.length)%rows.length]?.focus();}});
  }
  function closeModal(){modal?.remove();modal=null;document.body.classList.remove('prototype-modal-open');if(lastFocus?.isConnected)lastFocus.focus();else $('a[data-prototype-path*="/master_addresses/new"]')?.focus();}
  function openModal(markup){
    closeDropdown();closeMenus();lastFocus=document.activeElement;modal=document.createElement('div');modal.className='prototype-modal-root';modal.innerHTML='<div class="prototype-backdrop"></div>'+markup;document.body.append(modal);document.body.classList.add('prototype-modal-open');
    $('.modal',modal)?.setAttribute('aria-labelledby','prototype-modal-title');const title=$('.modal-title',modal);if(title)title.id='prototype-modal-title';
    $('.close',modal)?.addEventListener('click',closeModal);$('input:not([type="hidden"]):not(:disabled),select:not(:disabled),textarea,button.close',modal)?.focus();
    $('form',modal)?.addEventListener('submit',e=>e.preventDefault());return modal;
  }
  function smallModal(title,body,action,onSave,danger=false){
    const root=openModal(`<div class="modal show" style="display:block;z-index:1010" role="dialog" aria-modal="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content"><div class="modal-header"><h4 class="modal-title">${esc(title)}</h4><button class="close" type="button" aria-label="Close">×</button></div><form><div class="modal-body">${body}</div><div class="modal-footer"><button type="button" class="btn btn-white" data-cancel>Cancel</button><button type="submit" class="btn btn-${danger?'danger':'primary'}">${esc(action)}</button></div></form></div></div></div>`);
    $('[data-cancel]',root).onclick=closeModal;$('form',root).addEventListener('submit',e=>{e.preventDefault();e.stopPropagation();onSave?.(root);closeModal();});
  }
  const field=(label,value='',type='text')=>`<div class="form-group"><label>${esc(label)}<input class="form-control" name="${esc(label)}" type="${type}" value="${esc(value)}"></label></div>`;
  // Store field values rather than reconstructing edited addresses from display text.
  function readAddress(card){
    if(addressRecords.has(card))return addressRecords.get(card);
    const lines=$('address',card).innerText.split('\n').map(s=>s.trim()).filter(Boolean);
    const data={name:lines.shift()||'',address_type:$('.address-type',card).textContent.trim(),primary:card.dataset.primary==='true'};
    const phone=lines.findIndex(s=>s.startsWith('P: '));if(phone>=0)data.phone=lines.splice(phone,1)[0].slice(3);
    if(lines.at(-1)==='Australia')data.country=lines.pop();
    const city=lines.at(-1)?.match(/^(.*?)\s+([A-Z]{2,3})\s+(\d{4})$/);
    if(city){lines.pop();['city','state','postcode'].forEach((key,i)=>data[key]=city[i+1]);}
    ['line_1','line_2','line_3'].forEach((key,i)=>data[key]=lines[i]||'');
    addressRecords.set(card,data);return data;
  }
  function renderAddress(card,data){
    const lines=[data.line_1,data.line_2,data.line_3,[data.city,data.state,data.postcode].filter(Boolean).join(' '),data.country].filter(Boolean);
    $('address',card).innerHTML=`<div class="font-weight-bold">${esc(data.name||'Address')}</div>${lines.map(esc).join('<br>')}${data.phone?'<br>P: '+esc(data.phone):''}`;
    $('.address-type',card).textContent=data.address_type;
    card.dataset.primary=String(data.primary);
    $('.contact-copy',card).setAttribute('aria-label',`Copy ${data.name||'Address'} address`);
    $('.contact-more',card).setAttribute('aria-label',`Actions for ${data.name||'Address'} address`);
    addressRecords.set(card,data);
  }
  function addressForm(card){
    const root=openModal($('#address-prototype-template').innerHTML);
    const form=$('form',root), select=$('select',form), custom=$('input[name="master_address[address_type]"]',form);
    custom.id='master_address_custom_type';custom.setAttribute('aria-label','New address type');
    select.classList.remove('select2-hidden-accessible');select.removeAttribute('aria-hidden');select.removeAttribute('tabindex');
    if(select.nextElementSibling?.classList.contains('select2'))select.nextElementSibling.remove();
    const setTypeMode=useCustom=>{select.disabled=useCustom;custom.disabled=!useCustom;select.parentElement.classList.toggle('d-none',useCustom);custom.parentElement.classList.toggle('d-none',!useCustom);};
    $$('a[data-prototype-path=""]',form).forEach(link=>link.onclick=e=>{e.preventDefault();setTypeMode(link.textContent.trim()==='Add new address type');(custom.disabled?select:custom).focus();});
    if(card){
      $('.modal-title',root).textContent='Edit Address';$('[type="submit"]',form).value='Update Master address';
      const data=readAddress(card);
      Object.entries(data).forEach(([key,value])=>{const control=$('#master_address_'+key,form);if(control)control.value=value;});
      if(![...select.options].some(o=>o.value===data.address_type)){custom.value=data.address_type;setTypeMode(true);}
      $('#primary_address',form).checked=data.primary;
    }
    $('#master_address_name',form).focus();
    form.addEventListener('submit',e=>{
      e.preventDefault();e.stopPropagation();
      const data={};['name','line_1','line_2','line_3','city','state','postcode','country','phone'].forEach(key=>data[key]=$('#master_address_'+key,form).value.trim());
      data.address_type=(custom.disabled?select.value:custom.value.trim());data.primary=$('#primary_address',form).checked;
      const errors=$('.errors',form);errors.replaceChildren();
      if(!data.address_type||![data.line_1,data.line_2,data.line_3,data.city,data.state,data.postcode,data.country].some(Boolean)){
        const error=document.createElement('p');error.className='text-danger';error.role='alert';error.textContent=!data.address_type?'Enter an address type.':'Enter an address before saving.';errors.append(error);(!data.address_type?custom:$('#master_address_line_1',form)).focus();return;
      }
      if(data.primary)$$('#addresses > [id^="master_address_"]').forEach(other=>{const record=readAddress(other);if(other!==card&&record.address_type===data.address_type)renderAddress(other,{...record,primary:false});});
      const node=card||addressCardTemplate.cloneNode(true);
      if(!card){node.id='master_address_demo_'+(++addressSequence);$$('[id]',node).forEach(el=>el.removeAttribute('id'));$$('[aria-labelledby]',node).forEach(el=>el.removeAttribute('aria-labelledby'));$('#addresses').insertBefore(node,$('#addresses > .col-12:last-child'));}
      renderAddress(node,data);closeModal();toast(card?'Address updated in this prototype':'Address added in this prototype');
    });
  }
  let contactSequence=0;
  const contactNames={email:['Email','Email 1','Email 2','Email 3','Email 4'],phone:['Work phone','Mobile phone']};
  const contactAssets={plus:'assets/contact/plus.svg',ellipsis:'assets/contact/ellipsis.svg'};
  const contactIcon=name=>`<span class="contact-icon" aria-hidden="true"><img src="${contactAssets[name]}" alt=""></span>`;
  function addContact(kind,name='',value='',focus=true){
    const id='contact-'+(++contactSequence), title=kind==='email'?'Email':'Phone';
    const row=document.createElement('div');row.className='contact-row';row.dataset.kind=kind;
    row.innerHTML=`<div class="contact-name-field">
      <label for="${id}-name">${title} name</label>
      <div class="contact-name-existing"><select id="${id}-name" name="contacts[${id}][name]" class="select2-hidden-accessible" tabindex="-1" aria-hidden="true" data-contact-name="${kind}" data-placeholder="Choose a name"><option value=""></option>${contactNames[kind].map(n=>`<option${n===name?' selected':''}>${esc(n)}</option>`).join('')}</select><span class="select2 select2-container select2-container--default"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-label="${title} name" aria-haspopup="listbox" aria-expanded="false" tabindex="0"><span class="select2-selection__rendered"></span><span class="contact-triangle" aria-hidden="true"><img src="assets/contact/triangle.svg" alt=""></span></span></span></span></div>
      <input id="${id}-custom" class="form-control contact-custom-name" aria-label="New ${kind} name" name="contacts[${id}][name]" hidden disabled>
      <button type="button" class="contact-name-toggle">Add new ${kind} name</button>
    </div>
    <div class="contact-value-field"><label for="${id}-value">${kind==='email'?'Email address':'Phone number'}</label><input id="${id}-value" class="form-control" type="${kind==='email'?'email':'tel'}" name="contacts[${id}][value]" value="${esc(value)}"></div>
    <div class="dropdown contact-row-menu"><button type="button" class="btn contact-more" data-toggle="dropdown" aria-label="${title} actions" aria-haspopup="true" aria-expanded="false">${contactIcon('ellipsis')}</button><div class="dropdown-menu dropdown-menu-right"><button type="button" class="dropdown-item text-danger" data-remove-contact>Remove ${kind}</button></div></div>`;
    const select=$('select',row),custom=$('.contact-custom-name',row),toggle=$('.contact-name-toggle',row),existing=$('.contact-name-existing',row);
    renderSelection(select);
    toggle.onclick=()=>{
      closeDropdown();const useCustom=custom.hidden;
      if(!useCustom&&custom.value.trim()){
        const n=custom.value.trim();
        if(!contactNames[kind].includes(n)){contactNames[kind].push(n);$$(`select[data-contact-name="${kind}"]`).forEach(other=>other.add(new Option(n,n)));}
        select.value=n;renderSelection(select);
      }
      custom.hidden=!useCustom;custom.disabled=!useCustom;select.disabled=useCustom;existing.hidden=useCustom;
      const label=$('label',row);label.htmlFor=useCustom?custom.id:select.id;
      toggle.textContent=useCustom?'Choose existing':`Add new ${kind} name`;
      (useCustom?custom:$('.select2-selection',row)).focus();
    };
    $('[data-remove-contact]',row).onclick=()=>{closeDropdown();closeMenus();row.remove();$(`[data-add-contact="${kind}"]`).focus();};
    $('#'+kind+'-rows').append(row);if(focus)$('.select2-selection',row).focus();
  }
  $$('[data-add-contact]').forEach(button=>button.onclick=()=>addContact(button.dataset.addContact));
  addContact('email','Email','pminvitations.albanese@pm.gov.au',false);
  addContact('phone','Mobile phone','0407 001 102',false);
  document.addEventListener('click',e=>{
    const copy=e.target.closest('.contact-copy');if(!copy)return;
    const text=$('address',copy.closest('.contact-address')).innerText;
    navigator.clipboard.writeText(text).then(()=>toast('Address copied to clipboard')).catch(()=>toast('Unable to copy address. Please select and copy the text.'));
  });
  document.addEventListener('submit',e=>{
    e.preventDefault();if(modal?.contains(e.target))return;
    toast('Master person updated in this prototype');
  });
  document.addEventListener('click',e=>{
    const clear=e.target.closest('.select2-selection__clear,.select2-selection__choice__remove');
    if(clear){e.preventDefault();e.stopPropagation();const s=clear.closest('.select2').previousElementSibling;if(s.multiple){const o=[...s.options].find(o=>o.value===clear.dataset.optionValue||o.text===clear.parentElement.title);if(o)o.selected=false;}else s.value='';renderSelection(s);s.dispatchEvent(new Event('change',{bubbles:true}));closeDropdown();$('.select2-selection',s.nextElementSibling)?.focus();return;}
    const selection=e.target.closest('.select2-selection');if(selection){const s=selection.closest('.select2').previousElementSibling;if(s?.tagName==='SELECT')showOptions(s,selection);return;}
    const toggle=e.target.closest('[data-toggle="dropdown"]');if(toggle){e.preventDefault();const menu=toggle.nextElementSibling;const open=menu?.classList.contains('show');closeMenus();menu?.classList.toggle('show',!open);toggle.setAttribute('aria-expanded',String(!open));return;}
    const collapse=e.target.closest('[data-toggle="collapse"]');if(collapse){e.preventDefault();const target=collapse.dataset.target||collapse.dataset.prototypePath;const panel=$(target);panel?.classList.toggle('show');collapse.setAttribute('aria-expanded',String(panel?.classList.contains('show')));return;}
    const trash=e.target.closest('fieldset button');if(trash?.querySelector('.fa-trash')){trash.closest('fieldset').remove();return;}
    if(e.target.closest('#addNameDropdown + .dropdown-menu button')){
      const row=document.createElement('fieldset');row.className='form-group';row.innerHTML='<input class="form-control form-control-sm mb-1" aria-label="Name label" placeholder="Label e.g. Nickname" style="width:150px"><div class="row"><div class="col"><input class="form-control" aria-label="Additional name" placeholder="Enter name"></div><div class="col-auto"><button type="button" class="btn btn-link text-danger" aria-label="Remove name"><i class="far fa-trash"></i></button></div></div>';$('#addNameDropdown').closest('.form-group').before(row);$$('.dropdown-menu.show').forEach(x=>x.classList.remove('show'));$('input',row).focus();return;
    }
    const link=e.target.closest('a[data-prototype-path]');
    if(link){
      e.preventDefault();const path=link.dataset.prototypePath;
      if(modal&&path==='')return;
      if(path.startsWith('#')&&path!=='#')return;
      if(link.matches('.nav-link.active'))return;
      if(path.includes('template_id=')&&modal){
        const lines=$('small',link)?.innerText.split('\n').map(s=>s.trim()).filter(Boolean)||[];const form=$('form',modal);
        $('#master_address_name',form).value=$('strong',link).textContent;
        const city=lines.at(-1)?.match(/^(.*?)\s+([A-Z]{2,3})\s+(\d{4})$/);
        if(city)lines.pop();
        ['line_1','line_2','line_3'].forEach((key,i)=>$('#master_address_'+key,form).value=lines[i]||'');
        ['city','state','postcode'].forEach((key,i)=>$('#master_address_'+key,form).value=city?.[i+1]||'');
        $('#master_address_country',form).value='Australia';closeMenus();return;
      }
      if(path.includes('/master_addresses/new')){addressForm();return;}
      if(path.includes('/master_addresses/')){const card=link.closest('[id^="master_address_"]');if(path.endsWith('/edit'))addressForm(card);else smallModal('Delete address?','<p>This will remove this address from the prototype.</p>','Delete',()=>card?.remove(),true);return;}
      if(path.endsWith('/archive/edit')){smallModal('Delist & Archive Anthony Albanese','<p>Archive this master person?</p>','Delist & Archive',()=>toast('Archived in this prototype only'),true);return;}
      if(link.textContent.trim()==='Edit'&&path==='#'){['first_name','last_name'].forEach(k=>$('#master_person_'+k).readOnly=false);$('#master_person_first_name').focus();return;}
      if(link.textContent.trim()==='Clear'&&path==='#'){['first_name','last_name'].forEach(k=>$('#master_person_'+k).value='');return;}
      if(path.includes('/master_positions')&&!path.includes('/new')&&!path.includes('/edit')){$('h3.card-header-title', $('#staff'))?.scrollIntoView({behavior:'smooth'});$('#staff')?.scrollIntoView({behavior:'smooth'});return;}
      if(path.endsWith('/edit')||path.endsWith('/new')){const title=link.textContent.trim()||link.closest('.card')?.querySelector('h3')?.textContent.trim()||'Edit details';smallModal(title,field('Name',link.closest('.row')?.querySelector('h4')?.textContent.trim()||''),'Save changes',()=>toast('Changes saved in this prototype'));return;}
      toast('This prototype covers the master person edit page');return;
    }
    if(!e.target.closest('.prototype-options'))closeDropdown();
    if(!e.target.closest('.dropdown'))closeMenus();
  });
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'){if(dropdown)closeDropdown(true);else if($('.dropdown-menu.show'))closeMenus();else closeModal();}
    if(modal&&e.key==='Tab'){const focusable=$$('button,input,select,textarea,a[href]',modal).filter(x=>x.getClientRects().length&&!x.disabled);const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
    if((e.key==='Enter'||e.key===' ')&&e.target.matches('.select2-selection')){e.preventDefault();e.target.click();}
  });
  document.addEventListener('keydown',e=>{
    if((e.key==='Enter'||e.key===' ')&&e.target.matches('.select2-selection__clear,.select2-selection__choice__remove')){e.preventDefault();e.stopPropagation();e.target.click();}
  });
  function labelActions(){
    $$('fieldset button').forEach(button=>{button.removeAttribute('tabindex');button.setAttribute('aria-label','Remove '+(button.closest('fieldset').querySelector('label')?.textContent.trim()||'name'));});
    $$('.select2-selection__clear,.select2-selection__choice__remove').forEach(control=>{control.setAttribute('role','button');control.tabIndex=0;control.setAttribute('aria-label',control.classList.contains('select2-selection__clear')?'Clear selection':'Remove '+control.parentElement.title);});
    $$('#addresses > [id^="master_address_"]').forEach(card=>{
      card.tabIndex=0;
      $$('a[data-prototype-path*="/master_addresses/"]',card).forEach(link=>link.setAttribute('aria-label',(link.dataset.prototypePath.endsWith('/edit')?'Edit ':'Delete ')+$('address .font-weight-bold',card).textContent.trim()+' address'));
    });
  }
  labelActions();new MutationObserver(labelActions).observe(document.body,{childList:true,subtree:true});
  window.addEventListener('resize',()=>closeDropdown());
  // Captured enhancement widths must respond to the prototype's own viewport.
  $$('.select2-selection').forEach(e=>{const s=e.closest('.select2').previousElementSibling;const label=s?.id?document.querySelector(`label[for="${s.id}"]`):null;if(label){e.removeAttribute('aria-labelledby');e.setAttribute('aria-label',label.textContent.trim());}});
})();
